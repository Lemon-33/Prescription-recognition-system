from test_sql import Database
import json
import hashlib#导入密码加密模块
import datetime
import uuid
import base64

conf={'host':'localhost','user':'root','pw':'123456','db':'test','port':3306}

def insert_register(json1):#user,password1,password2
    db = Database(conf)
    data = json.loads(json1)
    judge = 1  # 保存到数据库变成0，没有保存到数据库保持1

    user=data['user']
    password1=data['password1']
    ###联调
    # 待加密信息为password1/password2 字符串形式
    # 创建md5对象
    hl = hashlib.md5()
    # 此处必须声明encode
    # # 若写法为hl.update(str)  报错为： Unicode-objects must be encoded before hashing
    hl.update(password1.encode(encoding='utf-8'))
    result_pd = hl.hexdigest()  # 字符串

    # 这组保存到数据库的时候会有引号 eg:'user'
    # user='\'\\\''+user+'\\\'\''
    # result_pd='\'\\\''+result_pd+'\\\'\''
    # 这组保存到数据库的时候没有引号
    user = '\'' + user + '\''
    result_pd = '\'' + result_pd + '\''
    userid = '\'' + str(uuid.uuid1()) + '\''
    judge = db.insert('user', {'userid': userid, 'username': user, 'password': result_pd})
    
    if judge==1:
        r_data='ACCOUNT_REGISTER_FAILED'
    else:
        # r_data=str(uuid.uuid1())
        r_data='successful'
    return r_data

    ###两个密码的时候
    # password2=data['password2']
    
    # if password1 == password2:
    #     # 待加密信息为password1/password2 字符串形式
    #     # 创建md5对象
    #     hl = hashlib.md5()
    #     # 此处必须声明encode
    #     # # 若写法为hl.update(str)  报错为： Unicode-objects must be encoded before hashing
    #     hl.update(password1.encode(encoding='utf-8'))
    #     result_pd = hl.hexdigest()  # 字符串

    #     # 这组保存到数据库的时候会有引号 eg:'user'
    #     # user='\'\\\''+user+'\\\'\''
    #     # result_pd='\'\\\''+result_pd+'\\\'\''
    #     # 这组保存到数据库的时候没有引号
    #     user = '\'' + user + '\''
    #     result_pd = '\'' + result_pd + '\''
    #     userid = '\'' + str(uuid.uuid1()) + '\''
    #     judge = db.insert('user', {'userid': userid, 'username': user, 'password': result_pd})
    # if judge==1:
    #     r_data='ACCOUNT_REGISTER_FAILED'
    # else:
    #     r_data=str(uuid.uuid1())
    # return r_data


def select_login(json2):#userid,password
    db = Database(conf)
    data = json.loads(json2)
    # judge = 1  # 连接到数据库且查询成功变成0，否则保持1
    user_id=data['userid']
    pswd=data['password']

    # 待加密信息为pswd
    # 创建md5对象
    hl = hashlib.md5()       
    # 此处必须声明encode
    # # 若写法为hl.update(str)  报错为： Unicode-objects must be encoded before hashing
    hl.update(pswd.encode(encoding='utf-8'))
    input_pd=hl.hexdigest()#字符串

    #数据库操作类
    db=Database(conf)
    user_id='\''+user_id+'\''
    information=db.select_one('user','userid='+user_id)#数据库里该用户的所有信息
    if information==False:
        r_data='No such user, please register'
        # self.write('没有此用户，请注册')
        # self.redirect('/register')
    else:
        # 有此用户 
        pw=information['password']#数据库里的密码
        if input_pd==pw:#密码正确
            r_data='successful'# 最终阶段 返回token值(放在HTTP的header里面，后续的每一个操作都有token值)  
        else:
            r_data='Password mistake'
    return r_data
            # 最终阶段 返回token值(放在HTTP的header里面，后续的每一个操作都有token值)  
            # token值以后用redis数据库 加时间戳
            # token=base64.b64encode(information['userid'])#数据库里的用户id
            # self.write(token)

            # 后续操作
            # 测试阶段
        

# 保存
class CoordinateCoupleInformation:
    order = int # 顺序
    key = str #关键字
    coordinate1 = str #坐标1
    coordinate2 = str #坐标2
    pictureFormat = str #图片格式
    pictureContent = str #图片内容

    def __init__(self,order,key,coordinate1,coordinate2,pictureFormat,pictureContent):
        self.order = order
        self.key = key
        self.coordinate1 = coordinate1
        self.coordinate2 = coordinate2
        self.pictureFormat = pictureFormat
        self.pictureContent = pictureContent


class ModuleInformation:# 整个模板信息
    CoordinateCoupleInfoList = list

    def __init__(self):
        self.CoordinateCoupleInfoList = []


class CoordinateCoupleInformation_:
    order = int
    key = str
    coordinate1 = str
    coordinate2 = str

    def __init__(self,order,key,coordinate1,coordinate2):
        self.order = order
        self.key = key
        self.coordinate1 = coordinate1
        self.coordinate2 = coordinate2


class JsonHelper:#处理json 之后保存到数据库
    def stringEditor_RemoveAllPartBetweenThese(self, stringText, startText, endText):
        startIndex = stringText.find(startText, 0, len(stringText))
        if startIndex == -1:
            return stringText
        endIndex = stringText.find(endText, 0, len(stringText))
        if endIndex == -1:
            return stringText
        while (startIndex != -1) & (endIndex != -1):
            endIndex = endIndex + len(endText)
            removeText = stringText[startIndex:endIndex]
            stringText = stringText.replace(removeText, '')
            startIndex = stringText.find(startText, 0, len(stringText))
            endIndex = stringText.find(endText, 0, len(stringText))
        return stringText

    def stringEditor_RemoveFirstPartBetweenThese(self, stringText, startText, endText):
        startIndex = stringText.find(startText, 0, len(stringText))
        if startIndex == -1:
            return stringText
        endIndex = stringText.find(endText, 0, len(stringText))
        if endIndex == -1:
            return stringText
        endIndex = endIndex + len(endText)
        removeText = stringText[startIndex:endIndex]
        stringText = stringText.replace(removeText, '')
        return stringText

    def stringEditor_TakeFirstRequiredTextFromString(self,stringText,startText, endText):
        startIndex = stringText.find(startText, 0, len(stringText))
        if startIndex == -1:
            return ''
        stringText = stringText[startIndex:]
        endIndex = stringText.find(endText, 0, len(stringText))
        if endIndex == -1:
            return ''
        return stringText[len(startText):endIndex]

    def json_serialize(obj):
        obj_dic = JsonHelper.class2dic(obj)
        return json.dumps(obj_dic,ensure_ascii=False)

    def class2dic(obj):
        obj_dic = obj.__dict__
        for key in obj_dic.keys():
            value = obj_dic[key]
            obj_dic[key] = JsonHelper.value2py_data(value)
        return obj_dic

    def value2py_data(value):
        if str(type(value)).__contains__('.'):
            # value 为自定义类
            value = JsonHelper.class2dic(value)
        elif str(type(value)) == "<class 'list'>":
            # value 为列表
            for index in range(0, value.__len__()):
                value[index] = JsonHelper.value2py_data(value[index])
        return value

    def dealWithRecievedJson(self,recievedJson):
        #  关于模板数据&切割图片Json的格式
        #  1.坐标对总数 coordinateAmount:xxx
        #  2.每一个坐标对:order:xxx key:xxx Coordinate1:aaa Coordinate2:bbb PictureContent:abcdefg PictureFormat:jpg
        #  这里直接将Json当成字符串去处理了
        coordinateAmount = int(JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"coordinateAmount":',','))
        #  获取总坐标对数目
        count = 1
        #  循环获取每个坐标对的信息
        coordinateInfoList = []
        while count <= coordinateAmount:
            coordinateInformation_order = int(JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"order":',',"'))
            coordinateInformation_key = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"key":"','",')
            coordinateInformation_coordinate1 = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"Coordinate1":"','",')
            coordinateInformation_coordinate2 = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"Coordinate2":"','",')
            coordinateInformation_pictureContent = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"PictureContent":"','",')
            if count == coordinateAmount:
                coordinateInformation_pictureFormat = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"PictureFormat":"','"}')
                recievedJson = JsonHelper.stringEditor_RemoveFirstPartBetweenThese(self, recievedJson, '"order"','"' + coordinateInformation_pictureFormat + '"')
            else:
                coordinateInformation_pictureFormat = JsonHelper.stringEditor_TakeFirstRequiredTextFromString(self,recievedJson,'"PictureFormat":"','",')
                recievedJson = JsonHelper.stringEditor_RemoveFirstPartBetweenThese(self, recievedJson, '"order":','"' + coordinateInformation_pictureFormat + '",')
            coordinateInformation = CoordinateCoupleInformation(coordinateInformation_order,coordinateInformation_key,coordinateInformation_coordinate1,coordinateInformation_coordinate2,coordinateInformation_pictureContent,coordinateInformation_pictureFormat)
            coordinateInfoList.append(coordinateInformation)
            #  print('-----Order' + str(count) + '-----')
            #  print(coordinateInfoList[count-1].order)
            #  print(coordinateInfoList[count-1].key)
            #  print(coordinateInfoList[count-1].coordinate1)
            #  print(coordinateInfoList[count-1].coordinate2)
            #  print(coordinateInfoList[count-1].pictureContent)
            #  print(coordinateInfoList[count-1].pictureFormat)
            count = count + 1
        #  所有坐标对的信息已经装在coordinateInfoList里面了 以上注释代码可以循环print查看
        #  接下来 将打包出新的模板数据Json并且存入数据库
        #  模板数据使用自定义类moduleInformation 实例是moduleInfo
        moduleInfo = ModuleInformation()
        count = 1
        while count <= coordinateAmount:
            coordinateInfo_order = coordinateInfoList[count - 1].order
            coordinateInfo_key = coordinateInfoList[count - 1].key
            coordinateInfo_coordinate1 = coordinateInfoList[count - 1].coordinate1
            coordinateInfo_coordinate2 = coordinateInfoList[count - 1].coordinate2
            coordinateInfo_ = CoordinateCoupleInformation_(coordinateInfo_order,coordinateInfo_key,coordinateInfo_coordinate1,coordinateInfo_coordinate2)
            moduleInfo.CoordinateCoupleInfoList.append(coordinateInfo_)
            #  print('-----Order' + str(count) + '-----')
            #  print(moduleInfo.CoordinateCoupleInfoList[count-1].order)
            #  print(moduleInfo.CoordinateCoupleInfoList[count-1].key)
            #  print(moduleInfo.CoordinateCoupleInfoList[count-1].coordinate1)
            #  print(moduleInfo.CoordinateCoupleInfoList[count-1].coordinate2)
            count = count + 1
        #  编译成json
        moduleJson = JsonHelper.json_serialize(moduleInfo)
        #  将图片保存至本地 暂时空缺
        return moduleJson

    def save(self,moduleJson):
        #  接下来是存入数据库的部分 暂时空缺
        db = Database(conf)
        #创一个新的数据表 第一列json 是否需要用户id
        moduleJson='\''+moduleJson+'\''
        judge = db.insert('jsontest', {'json': moduleJson})
        return judge

        

