#视图
import tornado.web
import DAL
import json

import hashlib#导入密码加密模块
import datetime
import uuid
import base64
from test_sql import Database

from tornado.web import RequestHandler

#查找多线程之后加的一些东西
import tornado.gen
import time
from tornado.concurrent import run_on_executor
from concurrent.futures import ThreadPoolExecutor


conf={'host':'localhost','user':'root','pw':'123456','db':'test','port':3306}

class IndexHandler(RequestHandler):#继承 RequestHandler包含所有的请求和处理
    def get(self):
        self.write("Hello,world")

# class BaseHandler(RequestHandler):
#     def get_current_user(self):
#         user_id = int(self.get_secure_cookie('user'))
#         if not user_id:
#             return None
#         db=Database(conf)
#         information=db.select_one('user','userid='+user_id)#数据库里该用户的所有信息
#         if information==False:
#             self.write('没有此用户，请注册')
#             self.redirect('/register')
#         else:
#             return user_id

async def registering(data1):#user,password1,password2
    r_data=DAL.insert_register(data1)
    return r_data

    # db = Database(conf)
    # judge = 1  # 保存到数据库变成0，没有保存到数据库保持1
    # if password1 == password2:
    #     # 待加密信息为password1/password2 字符串形式
    #     # 创建md5对象
    #     hl = hashlib.md5()
    #     # 此处必须声明encode
    #     # # 若写法为hl.update(str)  报错为： Unicode-objects must be encoded before hashing
    #     hl.update(password1.encode(encoding='utf-8'))
    #     result_pd = hl.hexdigest()  # 字符串

    #     # 这组保存到数据库的时候会有引号 eg:'user'
    #     # user='\'\\\''+user+'\\\'\''
    #     # result_pd='\'\\\''+result_pd+'\\\'\''
    #     # 这组保存到数据库的时候没有引号
    #     user = '\'' + user + '\''
    #     result_pd = '\'' + result_pd + '\''
    #     userid = '\'' + str(uuid.uuid1()) + '\''
    #     judge = db.insert('user', {'userid': userid, 'username': user, 'password': result_pd})

    # return judge

#注册
class RegisterHandler(RequestHandler):

    # async def get(self):
    #     self.render('register.html')

    async def post(self):
        # 获取请求参数
        # 注册的时候由前端进行两个密码是否一致的判断
        # 一致则对密码进行加密,传输到后端,后端再进行加密,然后保存到数据库

        user=self.get_argument('uname')
        password1=self.get_argument('pasw')#pasw
        # password2=self.get_argument('pwd2')
        # dic={'user':user,'password1':password1,'password2':password2}
        
        dic={'user':user,'password1':password1}
        data1=json.dumps(dic)

        judge = await registering(data1)
        # 最终规划：
        # judge==0:插入成功 返回userid 客户端接收到userid之后可以跳转到登录页面
        # 以后可以用手机号

        # 测试阶段
        # if judge == 0:  # 插入成功 #密码加密之后长度过长judge为false 但是跳转到了login
        #     # self.write('已保存到数据库') okk
        #     self.redirect('/login')
        # else:
        #     # self.write('请保证两次密码相同') okk
        #     self.redirect('/register')  # 多线程
        
        self.write(judge)#judge 等于0表示成功注册





async def logining(data2):#user,password1,password2
    r_data_login=DAL.select_login(data2)
    return r_data_login


#登录
class LoginHandler(RequestHandler):
    # async def get(self):
    #     self.render('login.html')

    async def post(self):
        #获取请求参数
        #从前端得到user_id和加密过的密码,二次加密之后和数据库进行对比

        user_id=self.get_argument('user_id')#用户登录的时候用的是用户id
        pswd=self.get_argument('pwd')
        dic={'userid':user_id,'password':pswd}
        data1=json.dumps(dic)

        # data1=self.get_argument('data')

        judge = await logining(data1)
        self.write(judge)


        # # 待加密信息为pswd
        # # 创建md5对象
        # hl = hashlib.md5()       
        # # 此处必须声明encode
        # # # 若写法为hl.update(str)  报错为： Unicode-objects must be encoded before hashing
        # hl.update(pswd.encode(encoding='utf-8'))
        # input_pd=hl.hexdigest()#字符串

        # #数据库操作类
        # db=Database(conf)
        # user_id='\''+user_id+'\''
        # information=db.select_one('user','userid='+user_id)#数据库里该用户的所有信息
        # if information==False:
        #     self.write('没有此用户，请注册')
        #     # self.redirect('/register')

        # # 有此用户 
        # pw=information['password']#数据库里的密码
        # if input_pd==pw:#密码正确
        #     # 最终阶段 返回token值(放在HTTP的header里面，后续的每一个操作都有token值)  
        #     # token值以后用redis数据库 加时间戳
        #     # token=base64.b64encode(information['userid'])#数据库里的用户id
        #     # self.write(token)

        #     # 后续操作


        #     # 测试阶段
        #     self.write('登陆成功')
        # else:
        #     self.redirect('/login')



# # 上传文件
#  class UploadfilesHandler(BaseHandler):
#      def get(self):
#          self.user=self.get_current_user()

#      def post(self):
#          #获取请求参数
#          out_template=self.get_argument('out_template')#得到输出模板类型
#          img1=self.request.files['img1']#img1是前端设的参数
#          time=datetime.datetime.now().strftime('%F%T')
#          #img1是字典类型，有body(二进制文件),content_type(u'image/png'),filename(u'1.png')
#          #遍历img1
#          for img in img1:
#              body=img.get('body','')
#              content_type=img.get('content_type','')
#              #filename=img.get('filename','')
#              filename=time+self.user
#          #将图片存放在upfile目录中
#          dir=config.settings['upfile']#绝对路径
#          with open(dir,'wb') as fw: #wb表示写入二进制文件
#              fw.write(body)

#          ###################
#          # 这里进行预处理
#          # 进行模板匹配
#          ###################
#          #将图片显示到浏览器
#          self.write(body)
#          #把模板区域显示到客户端


#          # 如果没有匹配模板
#          self.write("未找到模板")
#          # 让用户框选

#          #数据库操作类
#          db=Database(conf)
#          judge=db.insert('file',{'userid':self.user,'fileid':filename,'in_template':0,'out_template':out_template,
#          'format':content_type,'dir':dir,'time':time})
#          if judge==0:#插入成功
#              self.write('上传成功')
#          else:
#              self.write('上传失败,请再次上传')
#          #这里进行ocr识别




# #上传文件
# class UploadfilesHandler(BaseHandler):
#     def get(self):
#         self.user=self.get_current_user()

#     def post(self):
#         #获取请求参数
#         out_template=self.get_argument('out_template')#得到输出模板类型
#         img1=self.request.files['img1']#img1是前端设的参数
#         time=datetime.datetime.now().strftime('%F%T')
#         #img1是字典类型，有body(二进制文件),content_type(u'image/png'),filename(u'1.png')
#         #遍历img1
#         for img in img1:
#             body=img.get('body','')
#             content_type=img.get('content_type','')
#             #filename=img.get('filename','')
#             filename=time+self.user
#         #将图片存放在upfile目录中
#         dir=config.settings['upfile']#绝对路径
#         with open(dir,'wb') as fw: #wb表示写入二进制文件
#             fw.write(body)

#         ###################
#         # 这里进行预处理
#         # 进行模板匹配       
#         ###################   
#         #将图片显示到浏览器
#         self.write(body)
#         #把模板区域显示到客户端

#         # 如果没有匹配模板
#         # 让用户框选


async def saving(data2):#user,password1,password2
    jsonhelper = DAL.JsonHelper()
    r_data_login=jsonhelper.save(data2)#存到数据库
    return r_data_login


#保存
class SaveHandler(RequestHandler):
    async def get(self):
        self.render('json.html')

    async def post(self):
        testString = self.get_argument('json')
        jsonhelper = DAL.JsonHelper()
        testString = jsonhelper.dealWithRecievedJson(testString)
        judge = await saving(testString)
        if judge==0:
            self.write('成功')

        # dic={'userid':user_id,'password':pswd}
        # data1=json.dumps(dic)

        # judge = await logining(data1)
        # self.write(judge)
        
        # testString = '{"coordinateAmount":2,"order":1,"key":"名称","Coordinate1":"0,0","Coordinate2":"100,90","PictureContent":"12345","PictureFormat":"png","order":2,"key":"价格","Coordinate1":"0,10","Coordinate2":"100,100","PictureContent":"444","PictureFormat":"jpg"}'
        # jsonhelper = JsonHelper()
        # testString = jsonhelper.dealWithRecievedJson(testString)
        # print(testString)

        # judge = await logining(data1)
        # self.write(judge)